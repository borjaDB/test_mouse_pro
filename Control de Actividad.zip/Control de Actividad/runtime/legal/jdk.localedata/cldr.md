Please see ..\java.base\cldr.md
